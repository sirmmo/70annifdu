<?php

interface I_Template_Library
{
    function render($arg);
}
