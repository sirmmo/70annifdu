<?php

class A_Template_Normal extends Mixin
{
    function render($arg)
    {
        return $arg;
    }
}
