<?php

class C_Animal_Empty extends C_Component
{
}
