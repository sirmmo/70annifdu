<?php

interface I_Animal_Library
{
    function speak($arg);
}
