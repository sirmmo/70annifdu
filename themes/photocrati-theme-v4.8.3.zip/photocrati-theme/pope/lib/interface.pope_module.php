<?php

interface I_Pope_Module
{
	
}