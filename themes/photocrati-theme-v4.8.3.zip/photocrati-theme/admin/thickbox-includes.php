<script type='text/javascript'>
    /* <![CDATA[ */
    var thickboxL10n = {
        next: "Next &gt;",
        prev: "&lt; Prev",
        image: "Image",
        of: "of",
        close: "Close",
        noiframes: "This feature requires inline frames. You have iframes disabled or your browser does not support them.",
        loadingAnimation: "<?php echo includes_url("js/thickbox/loadingAnimation.gif")?>"
    };
    try{convertEntities(thickboxL10n);}catch(e){};
    /* ]]> */
</script>
<link rel="stylesheet" type="text/css" href="<?php echo esc_attr(includes_url('js/thickbox/thickbox.css'))?>" />
<script type="text/javascript" src="<?php echo esc_attr(includes_url('js/thickbox/thickbox.js'))?>"></script>