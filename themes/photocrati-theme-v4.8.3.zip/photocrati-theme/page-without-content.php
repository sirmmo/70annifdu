<?php
/*
Template Name: Page Without Content
*/
?>
<?php get_header(); ?>

    </div><!-- #main -->

</div><!-- #wrapper -->	
</div> <!-- #main_container -->

<?php wp_footer(); ?>

<?php 
include(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'footer-scripts.php');
?>

</body>
</html>
