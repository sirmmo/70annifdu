<div class='wrap'>
    <h2><?php _e('Photocrati Updates') ?></h2>
    <div class="content" id="update-content">
    	<div class="loader" id="update-loader"><span class="message"><?php _e('Loading...') ?></span></div>
    </div>
</div>
