<?php get_header(); ?>
	
		<div id="container">
         
    <?php 
  	if (Photocrati_Style_Manager::is_sidebar_enabled() && Photocrati_Style_Manager::get_active_preset()->sidebar_alignment_responsive == 'top') {
  		get_sidebar(); 
  	}
    ?>    
    	
			<div id="content-sm"><!-- Important!! If you remove the sidebar change the ID of this DIV to content -->
				
				<div id="post-0" class="post error404 not-found">
					<h1 class="entry-title"><?php _e( 'Not Found', 'photocrati-framework' ); ?></h1>
					<div class="entry-content">
						<p><?php _e( 'Apologies, but we were unable to find what you were looking for. Perhaps searching will help.', 'photocrati-framework' ); ?></p>
						<?php get_search_form(); ?>
					</div><!-- .entry-content -->
				</div><!-- #post-0 -->

			</div><!-- #content -->		
         
    <?php 
  	if (Photocrati_Style_Manager::is_sidebar_enabled() && Photocrati_Style_Manager::get_active_preset()->sidebar_alignment_responsive == 'bottom') {
  		get_sidebar(); 
  	}
    ?>    
    
<?php get_footer(); ?>
